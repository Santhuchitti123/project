SELECT
  *
FROM
  product
WHERE
  category = "Electronics"
  AND price > 500
ORDER BY
  price DESC;